echo "working directory:"
read input
if [ -n "$input" ]
then
	if [ ! -d "$input" ]
	then
		echo "Error!"
		exit 0
	fi

	if [ ! -x "$input" ]
	then
		echo "Error"
		exit 0
	fi
	cd "$input"
fi

for i in *;
do
chan=`echo $input | tr "[a-z] [A-Z]" "[A-Z] [a-z]"`
mv $input $chan
done
